﻿using Main_proj.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Main_proj
{
    public partial class Form1 : Form
    {
        EmployeLogic ob;
        public Form1()
        {
            InitializeComponent();
            ob = new EmployeLogic();
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            MessageBox.Show("hii");
            Employe c = new Employe();
            c.Empid = Convert.ToInt32(tbid.Text);
            c.Empname = tbname.Text.ToString();
            c.Dob = Convert.ToInt32(tbdob.Text);
            c.Phone = Convert.ToInt32(tbphone.Text);
            c.Email = tbemail.Text.ToString();
            c.Salary = Convert.ToInt32(tbsalary.Text);
            c.Deptid = Convert.ToInt32(tbdeptid.Text);
             string msg=ob.Add(c);   //using insert statement
            //string msg = ob.adddn(c);//using stored procedure
            MessageBox.Show(msg);
            dataGridView1.DataSource = ob.getAllData();
            tbid.Text = "";
            tbname.Text = "";
            tbdob.Text = "";
            tbphone.Text = "";
            tbemail.Text = "";
            tbsalary.Text = "";
            tbdeptid.Text = "";
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ob.getAllData();
        }

      
    }
}
