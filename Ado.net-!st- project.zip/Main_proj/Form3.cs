﻿using Main_proj.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Main_proj
{
    public partial class Form3 : Form
    {
        DepartementLogic ob;
        public Form3()
        {
            InitializeComponent();
            ob = new DepartementLogic();
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            MessageBox.Show("hii");
            Departement c = new Departement();
            c.Deptid = Convert.ToInt32(tbid.Text);
            c.Deptname = tbname.Text.ToString();
            c.Deptlocation = tblocation.Text.ToString();
            c.Managerid = Convert.ToInt32(tbmid.Text);
            string msg = ob.adddin(c);//using stored procedure
            MessageBox.Show(msg);
            dataGridView1.DataSource = ob.getData();
            tbid.Text = "";
            tbname.Text = "";
            tblocation.Text = "";
            tbmid.Text = "";
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ob.getData();
        }
    }
}
