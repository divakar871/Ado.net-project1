﻿create procedure tablejoin
as
begin
	select e.Empname,e.Dob,e.phone,e.Email,e.Salary,e.Deptid,d.Deptid,d.Deptname,
	d.Deptlocation,d.Managerid from Employe e inner join Departement d 
	on e.Empid=d.Managerid
end

exec tablejoin;