﻿create procedure spdelete
(
@empid int
)
as
begin
Delete from Employe where
EmpId =@empid;
end

exec spdelete 1

select * from Employe;