﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main_proj.Model
{
    class Employe
    {
        public int Empid { get; set; }
        public string Empname{ get; set; }
        public int Dob { get; set; }
        public int Phone { get; set; }
        public string Email { get; set; }
        public int Salary { get; set; }
        public int Deptid { get; set; }
    }
}
