﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Windows.Forms;

namespace Main_proj.Model
{
    class EmployeLogic
    {
        private string conStr = ConfigurationManager.ConnectionStrings["empdb"].ConnectionString;

       public List<Employe> getAllData()
        {
            List<Employe> li = new List<Employe>();
            string sql = "select * from Employe";
            SqlConnection conn = new SqlConnection(conStr);

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader sqr = cmd.ExecuteReader();
                while(sqr.Read())
                {
                    Employe ob = new Employe();
                    ob.Empid = Convert.ToInt32(sqr.GetValue(0));
                    ob.Empname = sqr.GetValue(1).ToString();
                    ob.Dob = Convert.ToInt32(sqr.GetValue(2));
                    ob.Phone= Convert.ToInt32(sqr.GetValue(3));
                    ob.Email = sqr.GetValue(4).ToString();
                    ob.Salary = Convert.ToInt32(sqr.GetValue(5));
                    ob.Deptid = Convert.ToInt32(sqr.GetValue(6));
                    li.Add(ob);
                }
            }
            catch(Exception)
            {
                MessageBox.Show("hlo");
                MessageBox.Show("db not connected");
            
            }
            finally
            {
                conn.Close();
            }
            return li;
        }
        //  USING INSERT COMMAND//


        public string Add(Employe c)
        {
            string msg = null;
            SqlConnection con = new SqlConnection(conStr);
            MessageBox.Show("comming");
            string sql = "insert into Employe values(" + c.Empid + ",'" + c.Empname + "',"+c.Dob+","+c.Phone+",'"+c.Email+"',"+c.Salary+","+c.Deptid+");";

            
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(sql, con);
                
                cmd.ExecuteNonQuery();
                msg = "data inserted seccessfully";
            }
            catch(Exception)
            {
                msg = "data is not inserted";
            }
            finally
            {
                con.Close();
            }

            return msg;
        }

        public string adddn(Employe c)
        {
            string msg = null;

            SqlConnection con = new SqlConnection(conStr);
            MessageBox.Show("comming");
            string sql = "dninsertEmployee";
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Empid", SqlDbType.Int).Value = c.Empid;
                cmd.Parameters.Add("@Empname", SqlDbType.VarChar, 50).Value = c.Empname;
                cmd.Parameters.Add("@Dob", SqlDbType.Int).Value = c.Dob;
                cmd.Parameters.Add("@Phone", SqlDbType.Int).Value = c.Phone;
                cmd.Parameters.Add("@Email", SqlDbType.VarChar, 50).Value = c.Email;
                cmd.Parameters.Add("@Salary", SqlDbType.Int).Value = c.Salary;
                cmd.Parameters.Add("@Deptid", SqlDbType.Int).Value = c.Deptid;
                cmd.ExecuteNonQuery();


               
                msg = "data inserted seccessfully";
            }
            catch (Exception)
            {
                msg = "data is not inserted";
            }
            finally
            {
                con.Close();
            }


            return msg;
        }


        public List<Departement> getAll()
        {
            List<Departement> li = new List<Departement>();
            string sql = "select * from Departement";
            SqlConnection conn = new SqlConnection(conStr);

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader sqr = cmd.ExecuteReader();
                while (sqr.Read())
                {
                    Departement ob = new Departement();
                    ob.Deptid = Convert.ToInt32(sqr.GetValue(0));
                    ob.Deptname = sqr.GetValue(1).ToString();
                    ob.Deptname = sqr.GetValue(1).ToString();
                    ob.Deptlocation = sqr.GetValue(4).ToString();
                    ob.Managerid = Convert.ToInt32(sqr.GetValue(5));

                    li.Add(ob);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("db not connected");

            }
            finally
            {
                conn.Close();
            }
            return li;
        }



        public string adddin(Departement c)
        {
            string msg = null;

            SqlConnection con = new SqlConnection(conStr);
            MessageBox.Show("comming");
            string sql = "dininsertDepartement";
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Empid", SqlDbType.Int).Value = c.Deptid;
                cmd.Parameters.Add("@Empname", SqlDbType.VarChar, 50).Value = c.Deptname;
                cmd.Parameters.Add("@Dob", SqlDbType.VarChar, 50).Value = c.Deptlocation;
                cmd.Parameters.Add("@Phone", SqlDbType.Int).Value = c.Managerid;

                cmd.ExecuteNonQuery();



                msg = "data inserted seccessfully";
            }
            catch (Exception)
            {
                msg = "data is not inserted";
            }
            finally
            {
                con.Close();
            }


            return msg;
        }

       public Employe search( int Salary)
        {
            //List<Employe> li = new List<Employe>();
            string sql = "select * from Employe where Salary="+Salary;
            SqlConnection conn = new SqlConnection(conStr);
            Employe ob = new Employe();
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader sqr = cmd.ExecuteReader();
                
                if (sqr.HasRows)
                {
                    while (sqr.Read())
                    {
                       
                        ob.Empid = Convert.ToInt32(sqr.GetValue(0));
                        ob.Empname = sqr.GetValue(1).ToString();
                        ob.Dob = Convert.ToInt32(sqr.GetValue(2));
                        ob.Phone = Convert.ToInt32(sqr.GetValue(3));
                        ob.Email = sqr.GetValue(4).ToString();
                        ob.Salary = Convert.ToInt32(sqr.GetValue(5));
                        ob.Deptid = Convert.ToInt32(sqr.GetValue(6));
                      //  li.Add(ob);
                    }
                }
                else
                {
                    ob = null;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("db not connected");

            }
            finally
            {
                conn.Close();
            }
            return ob;
        }



     /*   public Employe searchName(string ename)
        {

            string sql = "select * from Employe  where Empname="+ ename + "";
            SqlConnection conn = new SqlConnection(conStr);

            Employe ob = new Employe();
           
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader sqr = cmd.ExecuteReader();

                if (sqr.HasRows)
                {
                    while (sqr.Read())
                    {

                        ob.Empid = Convert.ToInt32(sqr.GetValue(0));
                        ob.Empname = sqr.GetValue(1).ToString();
                        ob.Dob = Convert.ToInt32(sqr.GetValue(2));
                        ob.Phone = Convert.ToInt32(sqr.GetValue(3));
                        ob.Email = sqr.GetValue(4).ToString();
                        ob.Salary = Convert.ToInt32(sqr.GetValue(5));
                        ob.Deptid = Convert.ToInt32(sqr.GetValue(6));
                        //  li.Add(ob);
                    }
                    MessageBox.Show("data retrived");
                }
                else
                {
                    ob = null;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("CANNOT CONNECT DATABASE");
            }
            finally
            {
                conn.Close();
            }
            return ob;
        }

    */


        public Employe searchid(int id)
        {
            //List<Employe> li = new List<Employe>();
            string sql = "select * from Employe where Empid=" + id;
            SqlConnection conn = new SqlConnection(conStr);
            Employe ob = new Employe();
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader sqr = cmd.ExecuteReader();

                if (sqr.HasRows)
                {
                    while (sqr.Read())
                    {

                        ob.Empid = Convert.ToInt32(sqr.GetValue(0));
                        ob.Empname = sqr.GetValue(1).ToString();
                        ob.Dob = Convert.ToInt32(sqr.GetValue(2));
                        ob.Phone = Convert.ToInt32(sqr.GetValue(3));
                        ob.Email = sqr.GetValue(4).ToString();
                        ob.Salary = Convert.ToInt32(sqr.GetValue(5));
                        ob.Deptid = Convert.ToInt32(sqr.GetValue(6));
                        //  li.Add(ob);
                    }
                }
                else
                {
                    ob = null;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("db not connected");

            }
            finally
            {
                conn.Close();
            }
            return ob;
        }





        public void updatedata(Employe c)
        {
            SqlConnection conn = new SqlConnection(conStr);
            string sql = "update2";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Empid", SqlDbType.Int).Value = c.Empid;
                cmd.Parameters.Add("@Empname", SqlDbType.VarChar, 50).Value = c.Empname;
                cmd.Parameters.Add("@Dob", SqlDbType.Int).Value = c.Dob;
                cmd.Parameters.Add("@Phone", SqlDbType.Int).Value = c.Phone;
                cmd.Parameters.Add("@Email", SqlDbType.VarChar, 50).Value = c.Email;
                cmd.Parameters.Add("@Salary", SqlDbType.Int).Value = c.Salary;
                cmd.Parameters.Add("@Deptid", SqlDbType.Int).Value = c.Deptid;
                cmd.ExecuteNonQuery();
                MessageBox.Show("updated the record");

            }
            catch (Exception)
            {
                MessageBox.Show("cannot update");
            }
            finally
            {
                conn.Close();
            }
        }


        //merge two tables


        public DataTable join()
        {
            DataTable merge = new DataTable();
            SqlConnection conn = new SqlConnection(conStr);
            string sql = "select *from employee emp Inner join Department d on emp.Empid= d.Managerid ";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
               
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                MessageBox.Show("hii");
                da.Fill(merge);
                
            }
            catch(Exception)
            {
                MessageBox.Show("Not retrive data");
            }
            finally
            {
                conn.Close();
            }



            return merge;
        }


        //Delete

        public string delete(int empid)
        {
            string str = null;
            string sql = "spdelete";

            SqlConnection conn = new SqlConnection(conStr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@empid", SqlDbType.Int).Value = empid;

                cmd.ExecuteNonQuery();
                str = "Particular data is deleted in a table";
            }
            catch (Exception)
            {
                MessageBox.Show("enable to delete the data");
            }
            finally
            {
                conn.Close();
            }
            return str;
        }

        //search by empname

        public Employe Searchbyname(string str)
        {
            Employe ob = new Employe();
            SqlConnection conn = new SqlConnection(conStr);
            string sql = "select * from Employe where Empname='" + str + "'";

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                
                SqlDataReader sqr = cmd.ExecuteReader();
                
                if (sqr.HasRows)
                {
                   
                    while (sqr.Read())
                    {
                       
                        ob.Empid = Convert.ToInt32(sqr.GetValue(0));
                        ob.Empname = sqr.GetValue(1).ToString();
                        ob.Dob = Convert.ToInt32(sqr.GetValue(2));
                        ob.Phone= Convert.ToInt32(sqr.GetValue(3));
                        ob.Email = sqr.GetValue(4).ToString();
                        ob.Salary = Convert.ToInt32(sqr.GetValue(5));
                        ob.Deptid = Convert.ToInt32(sqr.GetValue(6));
                    }

                }
                else
                {
                    ob = null;


                }

            }
            catch (Exception)
            {
                MessageBox.Show("COULDNT CONNECT TO DB");
            }
            finally
            {
                conn.Close();
            }


            return ob;

        }

    }


}
