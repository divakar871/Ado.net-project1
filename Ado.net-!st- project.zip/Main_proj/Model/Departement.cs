﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main_proj.Model
{
    class Departement
    {
        public int Deptid { get; set; }
        public string Deptname { get; set; }
        public string Deptlocation { get; set; }
        public int Managerid { get; set; }
    }
}
