﻿using Main_proj.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Main_proj
{
    public partial class Form6 : Form
    {
        EmployeLogic ob;
        public Form6()
        {
            InitializeComponent();
            ob = new EmployeLogic();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ob.getAllData();
           
            label2.Visible = false;
            tname.Visible = false;
            label3.Visible = false;
            tdob.Visible = false;
            label4.Visible = false;
            tphone.Visible = false;
            label5.Visible = false;
            temail.Visible = false;
            label6.Visible = false;
            tsalary.Visible = false;
            label7.Visible = false;
            tdeptid.Visible = false;
            bupdate.Visible = false;
        }

        private void bupdate_Click(object sender, EventArgs e)
        {
            Employe c = new Employe();
            c.Empid = Convert.ToInt32(tid.Text);
            c.Empname = tname.Text.ToString();
            c.Dob= Convert.ToInt32(tdob.Text);
            c.Phone= Convert.ToInt32(tphone.Text);
            c.Email = temail.Text.ToString();
            c.Salary= Convert.ToInt32(tsalary.Text);
            c.Deptid= Convert.ToInt32(tdeptid.Text);
            ob.updatedata(c);
            dataGridView1.DataSource = ob.getAllData();
        }

        private void btcheck_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(tid.Text);
            Employe c = ob.searchid(id);
            if(c==null)
            {
                MessageBox.Show("enter the valid data");
            }
            else
            {
               
                label2.Visible = true;
                tname.Visible = true;
                label3.Visible = true;
                tdob.Visible = true;
                label4.Visible = true;
                tphone.Visible = true;
                label5.Visible = true;
                temail.Visible = true;
                label6.Visible = true;
                tsalary.Visible = true;
                label7.Visible = true;
                tdeptid.Visible = true;
                bupdate.Visible = true;
                btcheck.Visible = false;
            }
        }
    }
}
